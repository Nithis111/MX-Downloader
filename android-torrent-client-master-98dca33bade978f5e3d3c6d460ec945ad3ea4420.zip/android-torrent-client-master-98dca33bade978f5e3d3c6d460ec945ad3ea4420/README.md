# Torrent Client

Torrent Client simple UI. Additional 'Search Engines' can be found here:

* [Search Engines](https://axet.gitlab.io/android-torrent-client/)

# Google Play

[![ Google Play](docs/google-play-badge.png)](https://play.google.com/store/apps/details?id=com.github.axet.torrentclient) 

Manual install

    ./libtorrent/debug.sh && gradle installDebug

# Translate

If you want to translate 'Torrent Client' to your language  please read following:

  * [HOWTO-Translate.md](/docs/HOWTO-Translate.md)

# Screenshots

![shot](/docs/shot.png)
